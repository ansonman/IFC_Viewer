using System.Windows;

namespace IFC_Viewer_00.Views
{
    public partial class SelectSegmentsForASSchematicWindow : Window
    {
        public SelectSegmentsForASSchematicWindow()
        {
            InitializeComponent();
        }
    }
}
