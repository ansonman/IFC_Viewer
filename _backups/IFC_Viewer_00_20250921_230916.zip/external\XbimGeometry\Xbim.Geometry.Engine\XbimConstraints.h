#pragma once
                                 
public enum class XbimConstraints : System::UInt32
{
	None = 0x0000,
	Closed = 0x0001,
	NotSelfIntersecting = 0x0002
	 
};

